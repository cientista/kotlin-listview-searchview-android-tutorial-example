package com.example.searchviewlistviewkotlin

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.AdapterView
import android.widget.ListView
import android.widget.SearchView
import android.widget.Toast

import java.util.ArrayList

class MainActivity : AppCompatActivity(), SearchView.OnQueryTextListener {

    // Declare Variables
    private var list: ListView? = null
    private var adapter: ListViewAdapter? = null
    private var editsearch: SearchView? = null
    private var moviewList: Array<String>? = null

    public override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Generate sample data

        moviewList = arrayOf(
            "Xmen",
            "Titanic",
            "Captain America",
            "Iron man",
            "Rocky",
            "Transporter",
            "Lord of the rings",
            "The jungle book",
            "Tarzan",
            "Cars",
            "Shreck"
        )

        // Locate the ListView in listview_main.xml
        list = findViewById(R.id.listview) as ListView

        movieNamesArrayList = ArrayList()

        for (i in moviewList!!.indices) {
            val movieNames = MovieNames(moviewList!![i])
            // Binds all strings into an array
            movieNamesArrayList.add(movieNames)
        }

        // Pass results to ListViewAdapter Class
        adapter = ListViewAdapter(this)

        // Binds the Adapter to the ListView
        list!!.adapter = adapter

        // Locate the EditText in listview_main.xml
        editsearch = findViewById(R.id.search) as SearchView
        editsearch!!.setOnQueryTextListener(this)

        list!!.onItemClickListener = AdapterView.OnItemClickListener { parent, view, position, id ->
            Toast.makeText(
                this@MainActivity,
                movieNamesArrayList[position].getAnimalName(),
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    override fun onQueryTextSubmit(query: String): Boolean {

        return false
    }

    override fun onQueryTextChange(newText: String): Boolean {
        adapter!!.filter(newText)
        return false
    }

    companion object {
        var movieNamesArrayList = ArrayList<MovieNames>()
    }
}