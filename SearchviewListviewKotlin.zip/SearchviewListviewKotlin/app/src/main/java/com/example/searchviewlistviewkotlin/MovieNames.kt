package com.example.searchviewlistviewkotlin

class MovieNames{

    private val movieName: String

    constructor(movieName: String){
        //code
        this.movieName = movieName
    }

    fun getAnimalName(): String {
        return this.movieName
    }

}

